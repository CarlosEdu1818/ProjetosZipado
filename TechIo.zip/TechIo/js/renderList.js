const formatter = Intl.NumberFormat('pt-br', {
    style: "currency",
    currency: 'BRL',
    maximumFractionDigits: 2
})

const listContainer = document.querySelector('.list');
const search = document.querySelector('#searchInput');
const heander = document.querySelector('.header');

const produtos = [
    {
        id: 1,
        title: 'Mouse razer - RGB Edition',
        price: 19.9,
        poster: './img/produtos/mouse.jpeg',
        estoque: 50
    },
    {
        id: 2,
        title: 'Teclado Razer - RGB Edition',
        price: 190.9,

        poster: './img/produtos/teclado.jpeg',
        estoque: 25,
    },
    {
        id: 3,
        title: 'Monitor 4k 60hz',
        price: 1900.9,
        poster: './img/produtos/monitor.jpeg',
        estoque: 15
    },
    {
        id: 4,
        title: 'Notebook ASUS',
        price: 19000.9,
        poster: './img/produtos/notebookAsus.jpeg',
        estoque: 7
    },
    {
        id: 5,
        title: 'Hd BarraCuda 2T',
        price: 500.0,
        poster: './img/produtos/hdModel001.jpeg',
        estoque: 8
    },
    {
        id: 6,
        title: 'Geforce GTX 1050 TI 4GB',
        price: 10000.0,
        poster: './img/produtos/GTX-1050-TI-4GB.jpeg',
        estoque: 4
    },{
        id: 7,
        title: 'Liquidificador',
        price: 250.0,
        poster: './img/produtos/liquidificador.jpeg',
        estoque: 1
    }
];

function renderListAndHeader(produtos){
    
    renderHeader(produtos);
    renderProdutos(produtos);
}

function searchInkeyUp(event) {
	const searched = event.target.value;

	const productsFound = produtosFilterInSearch(searched);

	productsFound.length > 0 ? renderListAndHeader(productsFound) 
        : (listContainer.innerHTML = 'Nenhum produto encontrado');
}

function produtosFilterInSearch(searched) {
	return produtos.filter((product) => {
        return product.title.toLowerCase().includes(searched.toLowerCase());
    });
}

search.addEventListener('keyup', _.debounce(searchInkeyUp, 400));

function renderHeader(produtos){
    const totalProdutos = produtos.length;

    heander.innerHTML = totalProdutos > 0
        ? `${totalProdutos} Produtos Encontrados` : (heander.innerHTML = '0 produtos Encontrados');
}


function renderProdutos(produtos) {
    let list = '';

    if (produtos.length <= 0) {
        list += `<div id="without-produtos">Nenhum produto disponível</div>`;
    } else {
        produtos.forEach((product) => {
            list += `
                <div class="col-12 col-sm-6 col-md-4 col-lg-3 col-xl-2"> <br>
                    <div class="card text-center bg-light">
                        <a href="#" class="position-absolute end-0 p-2 text-warning">
                            <i class="bi-suit-heart" style="font-size: 24px; line-height: 24px;"></i>
                        </a>
                        <a href="/produto.html">
                            <img src="${product.poster}" class="card-img-top" width="400px" height="155px">
                        </a>
                        <div class="card-header">
                            ${formatter.format(product.price)}
                        </div>
                        <div class="card-body">
                            <h5 class="card-title">${product.title}</h5>
                        </div>
                        <div class="card-footer">
                            <a href="carrinho.html" class="btn btn-dark mt-2 d-block">
                                Adicionar ao Carrinho
                            </a>
                            <small class="text-success">${product.estoque} em estoque</small>
                        </div>
                    </div>
                </div>
            `;
        });
    }

    listContainer.innerHTML = list;
}

renderListAndHeader(produtos);