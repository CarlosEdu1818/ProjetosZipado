/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Controller;

/**
 *
 * @author autologon
 */

import Model.Andress;
import com.google.gson.Gson;
import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;
import javax.swing.JOptionPane;

public class CEPService {
    static String webService = "http://viacep.com.br/ws/";
    static int successCode = 200;
    
    public static Andress searchAndressBy(String cep) throws Exception{
        cep = cep.replaceAll("-", "");
        
        String urlToCall = webService + cep + "/json/";
        
        try{
            URL url = new URL(urlToCall);
            HttpURLConnection connection = (HttpURLConnection) url.openConnection();

            if(connection.getResponseCode() != successCode){
                throw new RuntimeException("HTTP error code: " + connection.getResponseCode());
            }

            BufferedReader response = new BufferedReader(new InputStreamReader((connection.getInputStream())));
            String jsonInString = Util.convertJsonInString(response);

            Gson gson = new Gson();
            Andress theAndress = gson.fromJson(jsonInString, Andress.class);

            return theAndress;
        }catch(Exception e){
            JOptionPane.showMessageDialog(null, e, "Error!", 0);
            throw new Exception("Error: " + e);   
        }
        
    }
    
    
}
