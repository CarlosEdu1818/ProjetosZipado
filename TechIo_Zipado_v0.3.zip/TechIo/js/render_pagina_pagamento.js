const formatter = Intl.NumberFormat('pt-br', {
    style: "currency",
    currency: 'BRL',
    maximumFractionDigits: 2
});

const valor_total = document.querySelector('.valor_total');

valor_total.innerHTML = formatter.format(localStorage.getItem('valorTotal'));