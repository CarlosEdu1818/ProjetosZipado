const formatter = Intl.NumberFormat('pt-br', {
    style: "currency",
    currency: 'BRL',
    maximumFractionDigits: 2
});

const div_carrinho = document.querySelector("#carrinho");
const div_valor_total = document.querySelector(".valor_total");

let soma_total = 0;
let lista_carrinho = [];

function render(){
    console.log(localStorage.getItem('lista_carrinho'));

    list = '';

    lista_carrinho = JSON.parse(localStorage.getItem('lista_carrinho'));

    lista_carrinho.forEach((product) => {
        soma_total += product.price;

        list += `
            <li class="list-group-item py-3">
                <div class="row g-3">
                    <div class="col-4 col-md-3 col-lg-2">
                        <a href="${product.pagina}">
                            <img src="${product.poster}" class="img-thumbnail">
                        </a>
                    </div>
                    <div class="col-8 col-md-9 col-lg-7 col-xl-8 text-left align-self-center">
                        <h4>
                            <b><a href="#" class="text-decoration-none text-dark">
                                    ${product.title}</a></b>
                        </h4>
                        <h5>
                            <br>
                            <b>
                                 ${formatter.format(product.price)}
                            </b>
                        </h5>
                    </div>                            
                </div>
            </li>
        `;
    });

    div_carrinho.innerHTML = list;

    div_valor_total.innerHTML = formatter.format(soma_total);
    localStorage.setItem("valorTotal", soma_total);
}

if(div_valor_total <= 0){
    div_valor_total.innerHTML = formatter.format();
}

render();