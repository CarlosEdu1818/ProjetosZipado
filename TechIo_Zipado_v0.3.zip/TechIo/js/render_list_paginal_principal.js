const formatter = Intl.NumberFormat('pt-br', {
    style: "currency",
    currency: 'BRL',
    maximumFractionDigits: 2
})

const listOfertasDoDia = document.querySelector('.listOfertasDoDia');
const listVocePodeGostar = document.querySelector('.listVocePodeGostar');

const produtosOfertasDodia = [
    {
        id: 0,
        title: 'Mouse Razer',
        price: 300,
        desconto: 30,
        poster: '../img/produtos/mouse.jpeg',
        pagina: './paginas_produtos/mouse_razer.html',
        estoque: 10
    },

    {
        id: 1,
        title: 'Teclado Razer',
        price: 499,
        desconto: 10,
        pagina: '../paginas_produtos/teclado_razer.html',
        poster: './img/produtos/teclado.jpeg',
        estoque: 5
    },

    {
        id: 2,
        title: 'GTX 2080 TI',
        price: 4449.0,
        desconto: 17,
        pagina: '../paginas_produtos/RTX-2080-TI.html',
        poster: './img/produtos/RTX-2080-TI.jpeg',
        estoque: 5
    },

    {
        id: 3,
        title: 'Luneta Lunar',
        price: 266,
        desconto: 30,
        pagina: '../paginas_produtos/Luneta-Lunar-36050.html',
        poster: './img/produtos/luneta-lunar-36050.jpeg',
        estoque: 5
    },

    {
        id: 4,
        title: 'Monitor-4K',
        price: 1200,
        desconto: 30,
        pagina: '../paginas_produtos/Monitor.html',
        poster: './img/produtos/Monitor.jpeg',
        estoque: 5
    },

    {
        id: 5,
        title: 'Notebook',
        price: 1200,
        desconto: 10,
        pagina: '../paginas_produtos/notebook-Asus.html',
        poster: './img/produtos/NotebookAsus.jpeg',
        estoque: 5
    }
];

const produtosVocePodeGostar = [
    {
        id: 0,
        title: 'RTX 3060 TI',
        price: 5058.81,
        desconto: 15,
        pagina: '../paginas_produtos/RTX-3060-TI.html',
        poster: './img/produtos/RTX-3060-TI.jpeg',
        estoque: 10
    },

    {
        id: 1,
        title: 'Guitarra Eletr...',
        price: 845,
        desconto: 25,
        pagina: '../paginas_produtos/guitarra-eletrica.html',
        poster: './img/produtos/guitarra-eletrica-001.jpeg',
        estoque: 5
    },

    {
        id: 2,
        title: 'Memória RAM',
        price: 569.90,
        desconto: 25,
        pagina: '../paginas_produtos/memoria-RAM-8GB.html',
        poster: './img/produtos/memoria-RAM-8GB.jpeg',
        estoque: 5
    },

    {
        id: 3,
        title: 'Liquidificador',
        price: 100,
        desconto: 5,
        pagina: '../paginas_produtos/liquidificador.html',
        poster: './img/produtos/liquidificador.jpeg',
        estoque: 5
    },

    {
        id: 4,
        title: 'Motorola G22',
        price: 1115,
        desconto: 10,
        pagina: '../paginas_produtos/motorolo-moto-g22.html',
        poster: './img/produtos/motorolo-moto-g22.jpeg',
        estoque: 5
    },

    {
        id: 5,
        title: 'SSD 480GB',
        price: 1200,
        desconto: 17,
        pagina: '../paginas_produtos/SSD-480GB.html',
        poster: './img/produtos/SSD-480GB.jpeg',
        estoque: 5
    }
];

function render(produtos, list_ID, divToRender) {

    let list = '';

    produtos.forEach((product) => {
        list += `
            <div class="col-12 col-sm-6 col-md-4 col-lg-3 col-xl-2"> <br>
                <div class="card text-center bg-light">
                    <a href="#" class="position-absolute end-0 p-2 text-warning">
                        <i class="bi-suit-heart" style="font-size: 24px; line-height: 24px;"></i>
                    </a>
                    <a href="${product.pagina}">
                        <img src="${product.poster}" class="card-img-top" height="155px">
                    </a>
                    <div class="card-header">
                        <p style="font-size: 16px; color: red; margin-bottom: 0px;"><strike>${formatter.format(product.price)}</strike></p>
                        <p style="font-size: 25px; font-weight: 500; margin-bottom: 10px;">${formatter.format(product.price - (product.price * product.desconto/100))}</p> <em><p class="bg-danger">${product.desconto}% OFF </p></em>
                    </div>
                    <div class="card-body">
                        <h5 class="card-title">${product.title}</h5>
                    </div>
                    <div class="card-footer">
                        <button class="btn btn-dark mt-2 d-block" id="botao_carrinho" onclick="addProdutoCarrinho(${product.id}, ${list_ID})">
                            Adicionar ao carrinho</button>
                        <small class="text-success">${product.estoque} em estoque</small>
                    </div>
                </div>
            </div>
        `;
    });

    divToRender.innerHTML = list;
}

function addProdutoCarrinho(product_ID, list_ID){
    
    let list = [];

    // verificação da nulidade dos dados do localstorage
    if(JSON.parse(localStorage.getItem("lista_carrinho")) == null){
        // criando localStorage com uma lista vazia
        localStorage.setItem("lista_carrinho", JSON.stringify(list));
    }else{
        // retornado dados do localStorage: lista_carrinho
        list = JSON.parse(localStorage.getItem("lista_carrinho"));
    }

    // verificação de qual lista está sendo referida
    if(list_ID == 0){
                    
        // adicionando o produto referido na lista
        list.push(produtosOfertasDodia[product_ID]);
                        
        // adicionando a lista dentro do localStorage
        localStorage.setItem("lista_carrinho", JSON.stringify(list));
        
    }else if (list_ID == 1){
        // adicionando o produto referido na lista
        list.push(produtosVocePodeGostar[product_ID]);
                    
        // adicionando a lista dentro do localStorage
        localStorage.setItem("lista_carrinho", JSON.stringify(list));
    }   

    window.location = "carrinho.html";

    console.log(JSON.parse(localStorage.getItem("lista_carrinho")));
}

// Primeira lista para renderização

        //Lista dos produtos    // TAG <Div> para renderizar
render(produtosOfertasDodia, 0, listOfertasDoDia);

// Segunda lista para renderização

       //Lista dos produtos    // TAG <Div> para renderizar
render(produtosVocePodeGostar, 1, listVocePodeGostar);
