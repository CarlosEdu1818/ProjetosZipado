const qnt_produtos_carrinho = document.querySelector('.qnt_produtos_carrinho');

const list_carrinho = JSON.parse(localStorage.getItem("lista_carrinho"));

qnt_produtos_carrinho.innerHTML = list_carrinho.length;
