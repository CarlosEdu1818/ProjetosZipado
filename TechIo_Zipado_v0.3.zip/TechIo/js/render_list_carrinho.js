const formatter = Intl.NumberFormat('pt-br', {
    style: "currency",
    currency: 'BRL',
    maximumFractionDigits: 2
});

const div_carrinho = document.querySelector("#carrinho");

let div_valor_total = document.querySelector(".valor_total")
let soma_total = 0;
let lista_carrinho = [];

function render(){
    console.log(localStorage.getItem('lista_carrinho'));

    list = '';

    lista_carrinho = JSON.parse(localStorage.getItem('lista_carrinho'));

    lista_carrinho.forEach((product) => {
        soma_total += product.price;

        list += `
        <li class="list-group-item py-3">                   
            <div class="row g-3">
                    <div class="col-4 col-md-3 col-lg-2">
                        <a href="${product.pagina}">
                            <img src="${product.poster}" class="img-thumbnail">
                        </a>
                    </div>
                    <div class="col-8 col-md-9 col-lg-7 col-xl-8 text-left align-self-center">
                        <h4>
                            <b><a href="#" class="text-decoration-none text-dark">
                                    ${product.title}</a></b>
                        </h4>
                    </div>
                    <div
                        class="col-6 offset-6 col-sm-6 offset-sm-6 col-md-4 offset-md-8 col-lg-3 offset-lg-0 col-xl-2 align-self-center mt-3">
                        <div class="text-end mt-2">
                            <span class="text-dark">Valor Item: ${formatter.format(product.price)}</span>
                        </div>
                    </div>
                </div>
        </li>`;
    });

    div_valor_total.innerHTML = formatter.format(soma_total);

    div_carrinho.innerHTML = list;

    localStorage.setItem("valorTotal", soma_total);
}

if(soma_total == 0){
    div_valor_total.innerHTML = formatter.format(soma_total);
}

render();