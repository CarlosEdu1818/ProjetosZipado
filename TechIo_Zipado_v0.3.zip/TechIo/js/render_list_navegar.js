const formatter = Intl.NumberFormat('pt-br', {
    style: "currency",
    currency: 'BRL',
    maximumFractionDigits: 2
})

const div_to_render = document.querySelector('.list');
const search = document.querySelector('#searchInput');
const heander = document.querySelector('.header');

const produtos = [
    {
        id: 0,
        title: 'Mouse razer',
        price: 300.0,
        desconto: 30,
        pagina: '../paginas_produtos/mouse_razer.html',
        poster: './img/produtos/mouse.jpeg',
        estoque: 50
    },
    {
        id: 1,
        title: 'Teclado Razer',
        price: 499.00,
        desconto: 10,
        pagina: '../paginas_produtos/teclado_razer.html',
        poster: './img/produtos/teclado.jpeg',
        estoque: 25
    },
    {
        id: 2,
        title: 'Monitor 4k',
        price: 1200.0,
        desconto: 30,
        pagina: '../paginas_produtos/monitor.html',
        poster: './img/produtos/monitor.jpeg',
        estoque: 15
    },
    {
        id: 3,
        title: 'Notebook',
        price: 1200.0,
        desconto: 10,
        pagina: '../paginas_produtos/notebook-Asus.html',
        poster: './img/produtos/notebookAsus.jpeg',
        estoque: 7
    },
    {
        id: 4,
        title: 'Hd BarraCuda',
        price: 500.0,
        desconto: 0,
        pagina: '../paginas_produtos/HD-barracuda-2T.html',
        poster: './img/produtos/hdModel001.jpeg',
        estoque: 8
    },
    {
        id: 5,
        title: 'GTX 1050',
        price: 1799.0,
        desconto: 17,
        pagina: '../paginas_produtos/GTX-1050-TI-4GB.html',
        poster: './img/produtos/GTX-1050-TI-4GB.jpeg',
        estoque: 4
    },
    {
        id: 6,
        title: 'Liquidificador',
        price: 95.0,
        desconto: 5,
        pagina: '../paginas_produtos/liquidificador.html',
        poster: './img/produtos/liquidificador.jpeg',
        estoque: 1
    },

    {
        id: 7,
        title: 'Guitarra Eletr...',
        price: 845,
        desconto: 25,
        pagina: '../paginas_produtos/guitarra-eletrica.html',
        poster: './img/produtos/guitarra-eletrica-001.jpeg',
        estoque: 5
    },

    {
        id: 8,
        title: 'Memória RAM',
        price: 569.90,
        desconto: 25,
        pagina: '../paginas_produtos/memoria-RAM-8GB.html',
        poster: './img/produtos/memoria-RAM-8GB.jpeg',
        estoque: 5
    },

    {
        id: 9,
        title: 'Motorola G22',
        price: 1115,
        desconto: 10,
        pagina: '../paginas_produtos/motorolo-moto-g22.html',
        poster: './img/produtos/motorolo-moto-g22.jpeg',
        estoque: 5
    },

    {
        id: 10,
        title: 'SSD 480GB',
        price: 1200,
        desconto: 17,
        pagina: '../paginas_produtos/SSD-480GB.html',
        poster: './img/produtos/SSD-480GB.jpeg',
        estoque: 5
    },

    {
        id: 11,
        title: 'RTX 3060 TI',
        price: 5058.81,
        desconto: 15,
        pagina: '../paginas_produtos/RTX-3060-TI.html',
        poster: './img/produtos/RTX-3060-TI.jpeg',
        estoque: 10
    },

    {
        id: 12,
        title: 'Luneta Lunar',
        price: 266,
        desconto: 30,
        pagina: '../paginas_produtos/Luneta-Lunar-36050.html',
        poster: './img/produtos/luneta-lunar-36050.jpeg',
        estoque: 5
    },

    {
        id: 13,
        title: 'RTX 2080 TI',
        price: 4449,
        desconto: 17,
        pagina: '../paginas_produtos/RTX-2080-TI.html',
        poster: './img/produtos/RTX-2080-TI.jpeg',
        estoque: 5
    },

    {
        id: 14,
        title: 'Cabo HDMI',
        price: 27.90,
        desconto: 5,
        pagina: '../paginas_produtos/cabo_hdmi.html',
        poster: './img/produtos/cabo_hdmi-004.jpeg',
        estoque: 12
    },

    {
        id: 15,
        title: 'Mouse',
        price: 35,
        desconto: 17,
        pagina: '../paginas_produtos/mouse_simples.html',
        poster: './img/produtos/mouse_simples.jpeg',
        estoque: 7
    },


];

function renderListAndHeader(produtos){
    
    renderHeader(produtos);
    renderProdutos(produtos);
}

function searchInkeyUp(event) {
	const searched = event.target.value;

	const productsFound = produtosFilterInSearch(searched);

	productsFound.length > 0 ? renderListAndHeader(productsFound) 
        : (div_to_render.innerHTML = 'Nenhum produto encontrado') && renderHeader(productsFound);
}

function produtosFilterInSearch(searched) {
	return produtos.filter((product) => {
        return product.title.toLowerCase().includes(searched.toLowerCase());
    });
}

search.addEventListener('keyup', _.debounce(searchInkeyUp, 400));

function renderHeader(produtos){
    const totalProdutos = produtos.length;

    heander.innerHTML = totalProdutos > 0
        ? `${totalProdutos} Produtos Encontrados` : (heander.innerHTML = `0 produtos Encontrados`);
}

function renderProdutos(produtos) {
    let list = '';

    if (produtos.length <= 0) {
        list += `<div id="without-produtos">Nenhum produto disponível</div>`;
    } else {
        produtos.forEach((product) => {
            list += `
                <div class="col-12 col-sm-6 col-md-4 col-lg-3 col-xl-2"> <br>
                    <div class="card text-center bg-light">
                        <a href="#" class="position-absolute end-0 p-2 text-warning">
                            <i class="bi-suit-heart" style="font-size: 24px; line-height: 24px;"></i>
                        </a>
                        <a href="${product.pagina}">
                            <img src="${product.poster}" class="card-img-top" width="400px" height="155px">
                        </a>
                        <div class="card-header">
                            ${formatter.format(product.price - (product.price * product.desconto/100))}
                        </div>
                        <div class="card-body">
                            <h5 class="card-title">${product.title}</h5>
                        </div>
                        <div class="card-footer">
                            <button class="btn btn-dark mt-2 d-block" id="botao_carrinho" onclick="addProdutoCarrinho(${product.id})">
                            Adicionar ao carrinho</button>
                            <small class="text-success">${product.estoque} em estoque</small>
                        </div>
                    </div>
                </div>
            `;
        });
    }

    div_to_render.innerHTML = list;
}

function addProdutoCarrinho(product_ID){
    
    let list = [];

    // verificação da nulidade dos dados do localstorage
    if(JSON.parse(localStorage.getItem("lista_carrinho")) == null){
        // criando localStorage com uma lista vazia
        localStorage.setItem("lista_carrinho", JSON.stringify(list));
    }else{
        // retornado dados do localStorage: lista_carrinho
        list = JSON.parse(localStorage.getItem("lista_carrinho"));
    }
    window.location = "carrinho.html";

    console.log(JSON.parse(localStorage.getItem("lista_carrinho")));

    // adicionando o produto referido na lista
    list.push(produtos[product_ID]);
                    
    // adicionando a lista dentro do localStorage
    localStorage.setItem("lista_carrinho", JSON.stringify(list));
}

renderListAndHeader(produtos);