const formatter = Intl.NumberFormat('pt-br', {
    style: "currency",
    currency: 'BRL',
    maximumFractionDigits: 2
})

const listContainer = document.querySelector('.list');

const produtosOfertasDodia = [
    {
        id: 0,
        title: 'Mouse Razer',
        price: [399,299],
        desconto: 100,
        poster: './img/produtos/mouse.jpeg',
        estoque: 10
    },

    {
        id: 1,
        title: 'Teclado Razer',
        price: [699,599],
        desconto: 100,
        poster: './img/produtos/teclado.jpeg',
        estoque: 5
    },

    {
        id: 2,
        title: 'GTX 2090 TI',
        price: [1200,200],
        desconto: 1000,
        poster: './img/produtos/teclado.jpeg',
        estoque: 5
    },


];

function renderProdutos(produtos) {
    let list = '';

    if (produtos.length <= 0) {
        list += `<div id="without-produtos">Nenhum produto disponível</div>`;
    } else {
        produtos.forEach((product) => {
            list += `
                <div class="col-12 col-sm-6 col-md-4 col-lg-3 col-xl-2"> <br>
                    <div class="card text-center bg-light">
                        <a href="#" class="position-absolute end-0 p-2 text-warning">
                            <i class="bi-suit-heart" style="font-size: 24px; line-height: 24px;"></i>
                        </a>
                        <a href="/produto.html">
                            <img src="${product.poster}" class="card-img-top" height="155px">
                        </a>
                        <div class="card-header">
                            <strike>${formatter.format(product.price[0])}</strike> POR ${formatter.format(product.price[1])} <br> <em><p class="bg-danger">${formatter.format(product.desconto)} OFF </p></em>
                        </div>
                        <div class="card-body">
                            <h5 class="card-title">${product.title}</h5>
                        </div>
                        <div class="card-footer">
                            <a href="carrinho.html" class="btn btn-dark mt-2 d-block">
                                Adicionar ao Carrinho
                            </a>
                            <small class="text-success">${product.estoque} em estoque</small>
                        </div>
                    </div>
                </div>
            `;
        });
    }

    listContainer.innerHTML = list;
}

renderProdutos(produtosOfertasDodia);