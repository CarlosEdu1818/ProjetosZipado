/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Model;

/**
 *
 * @author autologon
 */
public class Andress {
    String logradouro, bairro, localidade, cep, complemento, uf, ibge, gia,ddd,
            siafi;
    
    public String getLogradouro(){
        return logradouro;
    }

    public String getCep() {
        return cep;
    }

    public String getComplemento() {
        return complemento;
    }

    public String getUf() {
        return uf;
    }

    public String getIbge() {
        return ibge;
    }

    public String getGia() {
        return gia;
    }

    public String getDdd() {
        return ddd;
    }

    public String getSiafi() {
        return siafi;
    }
    
    public String getBairro(){
        return bairro;
    }
    
    public String getLocalidade(){
        return localidade;
    }

    @Override
    public String toString() {
        return "Andress{" + "logradouro=" + logradouro + ", bairro=" + bairro + ", localidade=" + localidade + ", cep=" + cep + ", complemento=" + complemento + ", uf=" + uf + ", ibge=" + ibge + ", gia=" + gia + ", ddd=" + ddd + ", siafi=" + siafi + '}';
    }

    

}
