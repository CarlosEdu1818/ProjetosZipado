/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Controller;

import java.io.BufferedReader;
import java.io.IOException;

/**
 *
 * @author autologon
 */
public class Util {
    public static String convertJsonInString(BufferedReader buffereReader) throws IOException{
        String response, jsonInString = "";
        
        while((response = buffereReader.readLine()) != null){
            jsonInString += response;
        }
        return jsonInString;
    }
}
